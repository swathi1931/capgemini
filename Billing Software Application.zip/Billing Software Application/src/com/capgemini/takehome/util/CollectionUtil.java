package com.capgemini.takehome.util;

public class CollectionUtil {

}
