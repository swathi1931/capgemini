package com.cg.jpa.entites;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainInheritance {

		public static void main(String[] args){

			EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager em = factory.createEntityManager();
			em.getTransaction().begin();
			
			Book book = new Book();
			book.setAuthorId(1);
			book.setISBN(123);
			book.setPrice(2000);
			book.setTitle("Java");
			em.persist(book);
			
			Author author  = new Author();
			author.setAuthorId(101);
			author.setName("Shreyash");
			em.persist(author);
			
			em.getTransaction().commit();
			
			System.out.println("Added one book and author to database.");
			em.close();
			factory.close();
			
			
		}
}
