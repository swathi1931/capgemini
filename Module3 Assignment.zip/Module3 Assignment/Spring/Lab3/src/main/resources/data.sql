insert into product values (101,"Redmi Note 4",14000.00);
insert into product values (102,"Mi Band 3",2000.00);
insert into product values (103,"Jabra Elite Active 65T",15000.00);