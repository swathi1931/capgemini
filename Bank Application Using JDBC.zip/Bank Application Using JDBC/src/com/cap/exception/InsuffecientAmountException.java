package com.cap.exception;

@SuppressWarnings("serial")
public class InsuffecientAmountException extends RuntimeException {

	public InsuffecientAmountException(final String msg) {
		super(msg);

	}
}
