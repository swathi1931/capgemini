package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cap.bean.Account;

//import com.cap.exception.AccountNumberNotFoundException;
//import com.cap.exception.InsuffecientAmountException;
//import com.cap.exception.InputMismatchException;


public class AccountDaoImpl implements AccountDao {
      
	@Override
	public long depositDetails(long accountno, long depositAmt) {
		Connection conn=DBConnect.getConnection();
        PreparedStatement stmt2,t1;
        long set=0;
        try{
        stmt2=conn.prepareStatement("update bank set balance = balance+? WHERE accountno=?");
        t1 = conn.prepareStatement("insert into transaction values(tran.nextval,?,?,?,?,?)");
        stmt2.setLong(2,accountno);
        stmt2.setLong(1,depositAmt);
        t1.setLong(2,retriveData(accountno));
        set=stmt2.executeUpdate();
       
        String s="Deposit";
        long fromAcc=000000;
       
        t1.setString(1,s);
       
        t1.setLong(3,retriveData(accountno));
        t1.setLong(5,accountno);
        t1.setLong(4,fromAcc);
        t1.executeQuery();
    } catch (SQLException e) {
        e.printStackTrace();
    }
  
    return set;
    }
		
	@Override
	public long withdrawDetails(long accountno, long withdrawAmt) {
	    
		Connection conn=DBConnect.getConnection();
        PreparedStatement stmt2,t1;
        long set=0;
        try{
        stmt2=conn.prepareStatement("update bank set balance = balance-? WHERE accountno=?");
        stmt2.setLong(2,accountno);
        stmt2.setLong(1,withdrawAmt);
        set=stmt2.executeUpdate();
       
        String s="Withdraw";
        long fromAcc=000000;
        t1 = conn.prepareStatement("insert into transaction values(tran.nextval,?,?,?,?,?)");
        t1.setString(1,s);
        t1.setLong(2,accountno);
        t1.setLong(3,accountno);
        t1.setLong(5,accountno);
        t1.setLong(4,fromAcc);
        t1.executeQuery();
    } catch (SQLException e) {
        e.printStackTrace();
    }
  
    return set;
    }




		
	@Override
	public long retriveData(long accountno2) {
		
	        Connection conn =DBConnect.getConnection();
	        PreparedStatement pstmt;
	        long balance = 0;
			try {
				pstmt = conn.prepareStatement("select balance from bank where accountno=?");
				pstmt.setLong(1,accountno2);
	            ResultSet rs=pstmt.executeQuery();
	            rs.next();
	         balance =rs.getInt(1);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        
	        return balance;
	    }
		

	@Override
	public long fundTransfer(long accountno5, long accountno4, long fundTransfer) {
		 Connection conn =DBConnect.getConnection();
         PreparedStatement p2,t3;
         PreparedStatement p3;
         long set=0;
         long set1 = 0;
     try {
         p2 = conn.prepareStatement("update bank set balance = balance-? WHERE accNo=?");
         p2.setLong(1, fundTransfer);
         p2.setLong(2, accountno4);
         set=p2.executeUpdate();

         t3 = conn.prepareStatement("insert into transaction values(tran.nextval,?,?,?,?,?)");
         t3.setLong(2, accountno4);
         String s = "Transfer";
         t3.setString(1, s);
         t3.setLong(3, accountno4);
         t3.setLong(5, accountno5);
         t3.setLong(4, accountno4);
         t3.executeQuery();

         p3 = conn.prepareStatement("update bank set balance = balance+? WHERE accNo=?");
         p3.setLong(1, fundTransfer);
         p3.setLong(2, accountno5);
         set1=p3.executeUpdate();
         
         t3 = conn.prepareStatement("insert into transaction values(tran.nextval,?,?,?,?,?)");
         t3.setLong(2, accountno5);
         String s1 = "Transfer";
         t3.setString(1, s1);
         t3.setLong(3, accountno4);
         t3.setLong(5, accountno5);
         t3.setLong(4, accountno4);
         t3.executeQuery();

     } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
     }

         return set1;
 }

	@Override
	public long printTransaction() {
		   System.out.println(
	                "===============================================================================================================");
	       System.out.println(
	                "Tran  Id      Tran Type      New Balance     Old Balance          From Account          To Account    ");
	       System.out.println(
	                "===============================================================================================================");
	        Connection conn =DBConnect.getConnection();
	        PreparedStatement pstmt;
	        ResultSet r;
	            try {
	            	pstmt = conn.prepareStatement("select * from transaction");
	                r=pstmt.executeQuery();
	                while (r.next()) {
	                    System.out.println(r.getInt(1) + "           " + r.getString(2) + "           "+ r.getInt(3) + "            " + r.getInt(4) + "             "+r.getInt(5) + "            " + r.getInt(6) + "               ");
	               
	            }
	            }
	                catch (SQLException e) {
	                
	                e.printStackTrace();
	            }
	            return 0;
	    }
	

	@Override
	public long insertAccountHolder(Account accountno2) {
		
	        Connection conn=DBConnect.getConnection();

	         long accno = 0;
		try{
	           
		        PreparedStatement stmt=conn.prepareStatement("insert into bank values(?,?,?,?,?,accno.nextval)");
		       
		        stmt.setString(1,accountno2.getAccountHolder());
		        stmt.setLong(2,accountno2.getMobileno());
		        stmt.setString(3,accountno2.getAccountType());
		        stmt.setString(4,accountno2.getBranch());
		        stmt.setLong(5,accountno2.getBalance());
		       
		        int result=stmt.executeUpdate();
		        if(result >0){
		                    PreparedStatement pstmt=conn.prepareStatement("select accno.currval from dual");
		                    ResultSet rs=pstmt.executeQuery();
		                    rs.next();
		                    accno=rs.getLong(1);
		        }
		        }
		        catch(SQLException e)
		        {
		            e.printStackTrace();
		        }
		 
		        return accno;
	}

}
	









	
	
	