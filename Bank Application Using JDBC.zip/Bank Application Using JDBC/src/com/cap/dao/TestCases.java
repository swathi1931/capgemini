package com.cap.dao;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cap.dao.AccountDao;
import com.cap.dao.AccountDaoImpl;

 

public class TestCases {
   AccountDao dao= new AccountDaoImpl ();

 

    @Test
    public void test() {
        int balance=1000;
        int result=balance+800;
        int expectedResult=1800;
        assertEquals(expectedResult,result);
        System.out.println(expectedResult=result);
    }

 

    @Test
    public void test1()
    {
        int balance2=1000;
        int result2=balance2+800;
        int expectedResult2=2800;
        assertEquals(expectedResult2,result2);
        System.out.println(expectedResult2=result2);
    }
}