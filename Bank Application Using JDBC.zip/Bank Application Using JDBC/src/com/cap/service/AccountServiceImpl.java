package com.cap.service;



import com.cap.bean.Account;
import com.cap.dao.AccountDao;
import com.cap.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	Account bean = new Account();
	AccountDao dao = new AccountDaoImpl();

	@Override
	public long depositDetails(Long accountno1, Long depositAmt) {
		long Dep = dao.depositDetails(accountno1, depositAmt);
		return Dep;

	}

	@Override
	public long withdrawDetails(Long accountno3, Long withdraw) {
		long Wit = dao.withdrawDetails(accountno3, withdraw);
		return Wit;
	}

	@Override
	public long retriveData(long accountno2) {
		long acc = dao.retriveData(accountno2);
		return acc;
	}

	@Override
	public long fundTransfer(long accountno4, long accountno5, long fundTransfer) {
		long fundAmt = dao.fundTransfer(accountno4, accountno5, fundTransfer);// Data Sent to dao
		return fundAmt;// Return MainUi
	}

	@Override
	public long printTransactions() {
		// TODO Auto-generated method stub
		long trans = dao.printTransaction();
		return trans;
	}

	@Override
	public long insertAccountHolder(Account accountno2) {
		return dao.insertAccountHolder(accountno2);

	}

	@Override
	public boolean validateName(String accountHolder) {
		// TODO Auto-generated method stub
		if(accountHolder.matches("[A-Z][a-zA-z]*")){
			return true;
		}else{
		return false;
	}}

	@Override
	public boolean validateNumber(long mobileNo) {
		// TODO Auto-generated method stub
		String mobNum=Long.toString(mobileNo);
        if(mobNum.matches("[6-9][0-9]{9}"))
        {
            return true;
        }
        else
        {
		return false;
	}

	}
}
