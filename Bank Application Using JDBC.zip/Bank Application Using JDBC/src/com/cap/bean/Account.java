package com.cap.bean;

public class Account {
	private String accountHolder;
	private long mobileNo;
	private String accountType;
	private String branch;
	private long balance;
	private long accountNo;

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountholder) {
		accountHolder = accountholder;
	}

	public long getMobileno() {
		return mobileNo;
	}

	public void setMobileno(long mobileno) {
		mobileNo = mobileno;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accounttype) {
		accountType = accounttype;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String Branch) {
		branch = Branch;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long Balance) {
		balance = Balance;
	}

	public long getAccountno() {
		return accountNo;
	}

	public void setAccountno(long accountno) {
		accountNo = accountno;
	}

	@Override
	public String toString() {
		return "Account [AccountHolder=" + accountHolder + ", Mobileno=" + mobileNo + ", AccountType=" + accountType
				+ ", Branch=" + branch + ", Balance=" + balance + ", Accountno=" + accountNo + "]";
	}
}
