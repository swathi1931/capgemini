$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/suwatm/Desktop/BDD Module-4/registration/src/test/resources/register/register.feature");
formatter.feature({
  "line": 1,
  "name": "Registration_Page",
  "description": "",
  "id": "registration-page",
  "keyword": "Feature"
});
formatter.before({
  "duration": 2212671500,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "Successfull Registration",
  "description": "",
  "id": "registration-page;successfull-registration",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "The User is on Register homepage page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User clicks on Registerlink",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Enters the Userid",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Enters the Password",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Enters the Name",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Enters the Address",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Enters the Country",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Enters the Zipcode",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Enters the Email",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "Enters Sex-Female",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "Enters the Language-English",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "Enters About",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "Click Submit button",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "User is successfully registered",
  "keyword": "Then "
});
formatter.step({
  "line": 19,
  "name": "Browser is closed",
  "keyword": "And "
});
formatter.match({
  "location": "StepDef.the_User_is_on_Register_homepage_page()"
});
formatter.result({
  "duration": 2055932400,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.user_clicks_on_Registerlink()"
});
formatter.result({
  "duration": 107600,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enters_the_Userid()"
});
formatter.result({
  "duration": 3245899600,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enters_the_Password()"
});
formatter.result({
  "duration": 3152955000,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enters_the_Name()"
});
formatter.result({
  "duration": 3089077600,
  "error_message": "org.openqa.selenium.UnhandledAlertException: unexpected alert open: {Alert text : Name should not be empty and must have alphabet characters only}\n  (Session info: chrome\u003d77.0.3865.120): Name should not be empty and must have alphabet characters only\nBuild info: version: \u00273.4.0\u0027, revision: \u0027unknown\u0027, time: \u0027unknown\u0027\nSystem info: host: \u0027DIN77003746\u0027, ip: \u002710.219.35.26\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_181\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities [{networkConnectionEnabled\u003dfalse, chrome\u003d{chromedriverVersion\u003d77.0.3865.40 (f484704e052e0b556f8030b65b953dce96503217-refs/branch-heads/3865@{#442}), userDataDir\u003dC:\\Users\\suwatm\\AppData\\Local\\Temp\\1\\scoped_dir25804_2130840919}, timeouts\u003d{implicit\u003d0.0, pageLoad\u003d300000.0, script\u003d30000.0}, pageLoadStrategy\u003dnormal, unhandledPromptBehavior\u003ddismiss and notify, strictFileInteractability\u003dfalse, platform\u003dANY, proxy\u003dProxy(), goog:chromeOptions\u003d{debuggerAddress\u003dlocalhost:56679}, acceptInsecureCerts\u003dfalse, browserVersion\u003d77.0.3865.120, browserName\u003dchrome, javascriptEnabled\u003dtrue, platformName\u003dwindows nt, setWindowRect\u003dtrue}]\nSession ID: 117c2929f2f8cdcf5794a6d2bcd5e438\n*** Element info: {Using\u003dxpath, value\u003d//*[@id\u003d\"usrname\"]}\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:113)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:45)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:164)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:82)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:637)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:410)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:509)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:361)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:402)\r\n\tat com.cap.pagefactor.PageFactor.Sendvalue(PageFactor.java:24)\r\n\tat com.cap.registration.StepDef.enters_the_Name(StepDef.java:58)\r\n\tat ✽.And Enters the Name(C:/Users/suwatm/Desktop/BDD Module-4/registration/src/test/resources/register/register.feature:9)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StepDef.enters_the_Address()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDef.enters_the_Country()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDef.enters_the_Zipcode()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDef.enters_the_Email()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDef.enters_Sex_Female()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDef.enters_the_Language_English()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDef.enters_About()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDef.click_Submit_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDef.user_is_successfully_registered()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDef.browser_is_closed()"
});
formatter.result({
  "status": "skipped"
});
});