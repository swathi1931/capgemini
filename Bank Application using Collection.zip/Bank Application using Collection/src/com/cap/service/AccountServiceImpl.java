package com.cap.service;

import java.util.List;

import com.cap.bean.Account;
import com.cap.bean.Transaction;
import com.cap.dao.AccountDao;
import com.cap.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	Account bean = new Account();
	AccountDao dao = new AccountDaoImpl();

	@Override
	public long DepositDetails(Long accountno1, Long depositAmt) {
		long Dep = dao.DepositDetails(accountno1, depositAmt);
		return Dep;

	}

	@Override
	public long WithdrawDetails(Long accountno3, Long Withdraw) {
		long Wit = dao.WithdrawDetails(accountno3, Withdraw);
		return Wit;
	}

	@Override
	public Account retriveData(long accountno2) {
		Account acc = dao.retriveData(accountno2);
		return acc;
	}

	@Override
	public long FundTransfer(long accountno4, long accountno5, long FundTransfer) {
		long fundAmt = dao.FundTransfer(accountno4, accountno5, FundTransfer);// Data Sent to dao
		return fundAmt;// Return MainUi
	}

	@Override
	public List<Transaction> printTransactions() {
		// TODO Auto-generated method stub
		List<Transaction> trans = dao.printTransaction();
		return trans;
	}

	@Override
	public void insertAccountHolder(Account accountno2) {
		// TODO Auto-generated method stub
		long mobileno = accountno2.getMobileno();
		long Accountno = mobileno - 10000;
		accountno2.setAccountno(Accountno);
		dao.insertAccountHolder(accountno2);

	}

	@Override
	public boolean ValidateName(String AccountHolder) {
		// TODO Auto-generated method stub
		if(AccountHolder.matches("[A-Z][a-zA-z]*")){
			return true;
		}else{
		return false;
	}}

	@Override
	public boolean ValidateNumber(long Mobileno) {
		// TODO Auto-generated method stub
		String mobNum=Long.toString(Mobileno);
        if(mobNum.matches("[6-9][0-9]{9}"))
        {
            return true;
        }
        else
        {
		return false;
	}

	}
}
