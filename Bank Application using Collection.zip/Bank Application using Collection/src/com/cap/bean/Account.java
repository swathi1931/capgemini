package com.cap.bean;

public class Account {
	private String AccountHolder;
	private long Mobileno;
	private String AccountType;
	private String Branch;
	private long Balance;
	private long Accountno;

	public String getAccountHolder() {
		return AccountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		AccountHolder = accountHolder;
	}

	public long getMobileno() {
		return Mobileno;
	}

	public void setMobileno(long mobileno) {
		Mobileno = mobileno;
	}

	public String getAccountType() {
		return AccountType;
	}

	public void setAccountType(String accountType) {
		AccountType = accountType;
	}

	public String getBranch() {
		return Branch;
	}

	public void setBranch(String branch) {
		Branch = branch;
	}

	public long getBalance() {
		return Balance;
	}

	public void setBalance(long balance) {
		Balance = balance;
	}

	public long getAccountno() {
		return Accountno;
	}

	public void setAccountno(long accountno) {
		Accountno = accountno;
	}

	@Override
	public String toString() {
		return "Account [AccountHolder=" + AccountHolder + ", Mobileno=" + Mobileno + ", AccountType=" + AccountType
				+ ", Branch=" + Branch + ", Balance=" + Balance + ", Accountno=" + Accountno + "]";
	}
}
