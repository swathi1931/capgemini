package com.cap.bean;

public class Transaction {
	private int trancactionsId;
	private long fromAccount;
	private long toAccount;
	private long oldBalance;
	private long newBalance;
	private String TransactionType;

	public String getTransactionType() {
		return TransactionType;
	}

	public void setTransactionType(String string) {
		TransactionType = string;
	}

	@Override
	public String toString() {
		return "Transaction [trancactionsId=" + trancactionsId + ", fromAccount=" + fromAccount + ", toAccount="
				+ toAccount + ", oldBalance=" + oldBalance + ", newBalance=" + newBalance + ", TransactionType="
				+ TransactionType + "]";
	}

	public int getTrancactionsId() {
		return trancactionsId;
	}

	public void setTrancactionsId(int trancactionsId) {
		this.trancactionsId = trancactionsId;
	}

	public long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(long accountno3) {
		this.fromAccount = accountno3;
	}

	public long getToAccount() {
		return toAccount;
	}

	public void setToAccount(long accountno5) {
		this.toAccount = accountno5;
	}

	public long getOldBalance() {
		return oldBalance;
	}

	public void setOldBalance(long oldBalance) {
		this.oldBalance = oldBalance;
	}

	public long getNewBalance() {
		return newBalance;
	}

	public void setNewBalance(long newBalance) {
		this.newBalance = newBalance;
	}

}
