import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-printtransaction',
  templateUrl: './printtransaction.component.html',
  styleUrls: ['./printtransaction.component.css']
})
export class PrinttransactionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
