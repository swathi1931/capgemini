package com.cap.concurrent;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ConcHashMap extends Thread
{
	static ConcurrentHashMap chm= new ConcurrentHashMap();
	public void run(){
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Child");
		chm.put(40, "Welcome to ibm");
		System.out.println(chm);
	}
	public static void main(String[] args) throws InterruptedException{
		chm.put(10, "Welcome ");
		chm.put(20, "Hello");
		chm.put(30, "Hai");
		//System.out.println(chm);
		ConcHashMap t=new ConcHashMap();
		t.start();
		Set s=chm.keySet();
		Iterator itr = s.iterator();
		while(itr.hasNext()){
		Integer i = (Integer) itr.next();
		//System.out.println("");
	System.out.println("current key is:"+i+" "+ "and value is:"+chm.get(i));
	Thread.sleep(2000);}
	System.out.println(chm);
	}
}
