package com.cap.concurrent;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class FixedThread {
 public static void main(String[] args) throws InterruptedException,ExecutionException{
		ExecutorService Service = Executors.newFixedThreadPool(10);
		List<Future> allfutures =new ArrayList();
		for (int i=0; i<100;  i++){
			Future future = Service.submit(new task6());
			allfutures.add(future);
			
		}
		for (int i=0; i<100;  i++){
		Future<Integer>	future = allfutures.get(i);
		Integer result = future.get();
		System.out.println(result);	
		}
	}
}

class task6 implements Callable<Integer>{

	@Override
	public Integer call() throws Exception {
		Thread.sleep(1000);
		return new Random().nextInt();
	}
	
}