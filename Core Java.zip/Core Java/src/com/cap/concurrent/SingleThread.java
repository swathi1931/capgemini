package com.cap.concurrent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class SingleThread {
public static void main(String[] args) {
	ExecutorService Scervice = Executors.newSingleThreadExecutor();
	for(int i=0;i<10;i++)
	{
		Scervice.execute(new Task());
		
	}
	System.out.println("Thread name: "+Thread.currentThread());
	
}
}
class Task implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Thread name: "+Thread.currentThread().getName());
	}
	
}
