package com.cap.concurrent;


import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;

 

public class CopyOnWriteArraySetEx extends Thread
{
    static CopyOnWriteArraySet con= new CopyOnWriteArraySet();
    @Override
    public void run() 
    {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("Child Thread updating Array Set");
        con.add("C");
    }
    public static void main(String[] args) throws InterruptedException 
    {
        con.add("A");
        con.add("B");
        CopyOnWriteArraySetEx rx=new CopyOnWriteArraySetEx();
        rx.start();
        Iterator itr=con.iterator();
        while(itr.hasNext())
        {
            String values=(String) itr.next();
            System.out.println("Main Thread Executing...."+values);
            Thread.sleep(1000);
            System.out.println(con);
        }
    }
}