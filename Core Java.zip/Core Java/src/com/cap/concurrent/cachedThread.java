package com.cap.concurrent;


import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class cachedThread {
public static void main(String[] args) {
	ExecutorService Scervice = Executors.newCachedThreadPool();
	for(int i=0;i<100;i++)
	{
		Scervice.execute(new Tasks());
		
	}
	System.out.println("Thread name: "+Thread.currentThread());
	
}
}
class Tasks implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Thread name: "+Thread.currentThread().getName());
	}
	
}
