package com.cap.concurrent;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
	public class ScheduleThread {
	public static void main(String[] args) {
		ScheduledExecutorService Scervice = Executors.newScheduledThreadPool(0);
		for(int i=0;i<10;i++)
		{
			//Scervice.schedule(new Task2(),10,TimeUnit.SECONDS);
			//Scervice.scheduleAtFixedRate(new Task2(),15,10,TimeUnit.SECONDS);
			Scervice.scheduleWithFixedDelay(new Task2(),15,10,TimeUnit.SECONDS);
		}
		System.out.println("Thread name: "+Thread.currentThread());
		
	}
	}
	class Task2 implements Runnable{

		@Override
		public void run() {
			Date date=new Date();
			System.out.println(Thread.currentThread().getName()+""+new SimpleDateFormat("HH:mm:ss").format(date));
		
		try{
			Thread.sleep(1000);
		}catch (InterruptedException e){
			e.printStackTrace();
		}
		
		
	}
	}

