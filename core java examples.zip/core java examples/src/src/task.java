import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class task {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		// 5 steps + 1
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter userName:");
		String uname = scanner.next();
		System.out.println("Enter password:");
		String pass = scanner.next();


		// step 1: loading the driver class --->OracleDriver
		Class.forName("oracle.jdbc.driver.OracleDriver");// odbc.jar//package name

		// step 2: create the connection
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg419",
				"training419");

		// step 3: create the statement
		PreparedStatement stmt = conn.prepareStatement("select * from gmail where username=? and password=?");
		stmt.setString(1, uname);
		stmt.setString(2, pass);
		ResultSet val = stmt.executeQuery();
		 if(val.next())
		    {
		         System.out.println("Login Success!!");
		        }else{
		        	System.out.println("Login Failed!!");
		        }
		        	
	
		// step 5:close the connection
		conn.close();


	}


}
