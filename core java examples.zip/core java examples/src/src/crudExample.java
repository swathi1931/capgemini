
	import java.sql.Connection;
    import java.sql.DriverManager;
	import java.sql.SQLException;
	import java.sql.Statement;

	public class crudExample {

	    public static void main(String[] args) throws ClassNotFoundException, SQLException {
	        // 5 steps + 1
	    	
	        //step 1: loading the driver class --->OracleDriver
	        Class.forName("oracle.jdbc.driver.OracleDriver");//odbc.jar//package name
	        
	        //step 2: create the connection
	        Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg419","training419");
	        
	        //step 3: create the statement
	        Statement stmt=conn.createStatement();
	        
	        //step 4: execute Query
//	        boolean val=stmt.execute("create table employee(eid number(10),ename varchar2(20))");
//	        System.out.println("table created:"+val);
	        
//	        int val=stmt.executeUpdate("insert into employee values(100,'swathi')");
//	        System.out.println( val+" "+"Row inserted");
	        
//	        int val=stmt.executeUpdate("UPDATE employee set ename='surya' where eid=100");
//	        System.out.println( val+" "+"Row updated");
	        
//	        int val=stmt.executeUpdate("delete from employee where eid=100");
//	        System.out.println( val+" "+"Row deleted");
	        
	        
	        
	        // ddl execute()-->boolean
	        // dml executeUpdate()-->int
	        // drl executeQuery()--->ResultSet
	        
	        //step 5:close the connection
	        conn.close();
	        

	 

	    }

	 

	}

