import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class register {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		// 5 steps + 1
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter userName:");
		String uname = scanner.next();
		System.out.println("Enter password:");
		String pass = scanner.next();
		System.out.println("Enter name:");
		String name = scanner.next();


		// step 1: loading the driver class --->OracleDriver
		Class.forName("oracle.jdbc.driver.OracleDriver");// odbc.jar//package
															// name

		// step 2: create the connection
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg419",
				"training419");

		// step 3: create the statement
		PreparedStatement stmt = conn.prepareStatement("insert into gmail values(?,?,?)");
		stmt.setString(1, uname);
		stmt.setString(2, pass);
		stmt.setString(3, name);
		
		int val = stmt.executeUpdate();
		if (val>0) {
			System.out.println("Register Success!!");
		} else {
			System.out.println("Failed!!");
		}

		// step 5:close the connection
		conn.close();

	}

}
