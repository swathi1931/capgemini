package com.cg.ct.service;

import java.util.List;

import com.cg.ct.dao.EmployeeDao;
import com.cg.ct.dao.EmployeeDaoImpl;
import com.cg.ct.entities.Employee;




public class EmployeeServiceImpl implements EmployeeService {
	
	 EmployeeDao dao;
	public EmployeeServiceImpl() {
		dao = new EmployeeDaoImpl();
	}
	@Override
	public void addEmployee(Employee employee) {
		dao.beginTransaction();
		dao.addEmployee(employee);
		dao.commitTransaction();
		
	}

	@Override
	public void updateEmployee(Employee employee) {
		dao.beginTransaction();
		dao.updateEmployee(employee);
		dao.commitTransaction();
		
	}

	@Override
	public void removeEmployee(Employee employee) {
		dao.beginTransaction();
		dao.removeEmployee(employee);
		dao.commitTransaction();
		
	}

	@Override
	public Employee findEmployeeById(int id) {
		Employee employee  = dao.getEmployeeById(id);
		return employee;
	}
	@Override
	public List<Employee> printEmployee() {
		return dao.printEmployee();
		
	}

}

