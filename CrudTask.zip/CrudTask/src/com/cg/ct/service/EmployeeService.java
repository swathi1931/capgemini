package com.cg.ct.service;

import java.util.List;

import com.cg.ct.entities.Employee;


public interface EmployeeService {
	public abstract void addEmployee(Employee employee);

	public abstract void updateEmployee(Employee employee);

	public abstract void removeEmployee(Employee employee);

	public abstract Employee findEmployeeById(int id);
	
	 List<Employee> printEmployee();
}
