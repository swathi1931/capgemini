package com.cg.ct.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.ct.entities.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

		private EntityManager entityManager;
		 public EmployeeDaoImpl() {
		        entityManager = JPAUtil.getEntityManager();
		    }
		@Override
		public Employee getEmployeeById(int id) {
			Employee employee = entityManager.find(Employee.class, id);
			return employee;
		}

		@Override
		public void addEmployee(Employee employee) {
			entityManager.persist(employee);
			
		}

		@Override
		public void removeEmployee(Employee employee) {
			entityManager.remove(employee);
			
		}

		@Override
		public void updateEmployee(Employee employee) {
			entityManager.merge(employee);
			
		}

		@Override
		public void commitTransaction() {
			entityManager.getTransaction().commit();
			
		}

		@Override
		public void beginTransaction() {
			entityManager.getTransaction().begin();
			
		}
		@Override
		public List<Employee> printEmployee() {
			TypedQuery q2=entityManager.createQuery("select c from Employee c",Employee.class);
			 List<Employee> l1=q2.getResultList();
	
				return l1;
		}


}
