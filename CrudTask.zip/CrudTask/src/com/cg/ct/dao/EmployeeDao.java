package com.cg.ct.dao;

import java.util.List;

import com.cg.ct.entities.Employee;


public interface EmployeeDao {
	public abstract Employee getEmployeeById(int id);

	public abstract void addEmployee(Employee employee);

	public abstract void removeEmployee(Employee employee);

	public abstract void updateEmployee(Employee employee);

	public abstract void commitTransaction();

	public abstract void beginTransaction();
   
	List<Employee> printEmployee();

}
