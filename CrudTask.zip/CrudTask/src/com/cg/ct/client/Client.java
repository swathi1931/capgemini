package com.cg.ct.client;


import java.util.List;
import java.util.Scanner;

import com.cg.ct.entities.Employee;
import com.cg.ct.service.EmployeeService;
import com.cg.ct.service.EmployeeServiceImpl;

public class Client {
	
	static EmployeeService service = new EmployeeServiceImpl();
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
//		Employee emp= new Employee();
		while (true) {
			System.out.println("Welcome to Employee Operation");
			System.out.println("1.Create");
			System.out.println("2.Update");
			System.out.println("3.Find");
			System.out.println("4.Remove ");
			System.out.println("5.Print");
			int option = scanner.nextInt();
			switch (option) {
			case 1:
				
				System.out.println("Enter Id:");
				int empId = scanner.nextInt();
				System.out.println("Enter Name:");
				String empName = scanner.next();
				System.out.println("Enter Address");
				String empAdd = scanner.next();
				System.out.println("Enter Salary:");
				int empSal = scanner.nextInt();
				Employee emp= new Employee(empId, empName, empAdd, empSal);
				service.addEmployee(emp);
				System.out.println("**ADDED TO DB**");
				break;	
				
			case 2:
				System.out.println("Enter Id");
                int eid2 = scanner.nextInt();
                emp = service.findEmployeeById(eid2);
                if(emp==null){
                    System.out.println("***Employee id does not exists***");
                }
                else{
                System.out.println("ID:" + emp.getEmpId());
                System.out.println(" Name:" + emp.getEmpName());
                System.out.println("SAL:" + emp.getEmpSal());

                System.out.println("Enter employee name");
                String ename1 = scanner.next();
                emp.setEmpName(ename1);
                service.updateEmployee(emp);}
                break;
				
			case 3:
				System.out.println("Enter Id:");
				int empId1 = scanner.nextInt();
				Employee emp1=service.findEmployeeById(empId1);
				System.out.println(emp1.getEmpName()+" "+emp1.getEmpSal());
				break;	
				
			case 4:
				System.out.println("Enter Id:");
				int empId2 = scanner.nextInt();
				Employee emp2=service.findEmployeeById(empId2);
				service.removeEmployee(emp2);;
				System.out.println("Deleted");
				break;	
				
			case 5:
				System.out.println("**EMPLOYEE DETAILS**");
				List<Employee> l1=service.printEmployee();
			       for(Employee e5:l1)
			        {
			            System.out.println(e5.getEmpId());
			            System.out.println(e5.getEmpName());
			            System.out.println(e5.getEmpAdd());
			            System.out.println(e5.getEmpSal());
			        }
			}
		}}}
				
				


		
	
