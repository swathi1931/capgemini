package lab3;


import java.util.Arrays;


public class Reversing3
{
    public int[] getSorted(int a[])
    {
         for (int i = a.length-1; i >= 0; i--)
         {  
                System.out.print(a[i] + " "); 
         }
         Arrays.sort(a);
         return a;
    }
    public static void main(String[] args) 
    {
    	Reversing3 e=new Reversing3();
        
            int a[]={2,3,6};
            
            a=e.getSorted(a);
            System.out.println();
            for(int i:a)
            {
            System.out.print(i+" ");
            
            }
    }
}
 




