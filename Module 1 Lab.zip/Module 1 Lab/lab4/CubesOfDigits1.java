package lab4;

import java.util.Scanner;
public class CubesOfDigits1 {
   static int calculateDifference(int n) // Calculate the difference
    {
        int  sum=0;
        for(int i=1;i<=n;i++)
        {
            // sum of cubes
            sum=sum+(i*i*i);
        }
        return sum;
    }

 

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter any number:");
        int n=sc.nextInt();
        System.out.println(CubesOfDigits1.calculateDifference(n));
    }}