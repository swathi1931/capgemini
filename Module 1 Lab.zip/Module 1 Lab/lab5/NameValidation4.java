package lab5;


class NameNotvalid extends Exception
{
	public NameNotvalid(String errMsg) 
	{
		super(errMsg);	
		
	}
}
class NameCheck
{
	void check(String fname,String lname) throws NameNotvalid
	{
		if((fname.length()==0) && (lname.length()==0))
		{
			throw new NameNotvalid("Your name is empty \n Please enter the name properly");
		}
		else
		{
			System.out.print("Your Fullname is: "+fname+" "+lname);
		}
				
	}
}
public class NameValidation4 {

	public static void main(String[] args) throws NameNotvalid {
		
		NameCheck obj=new NameCheck();
		obj.check("","");
	}

}

