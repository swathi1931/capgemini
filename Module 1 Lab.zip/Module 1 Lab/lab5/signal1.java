package lab5;

import java.util.Scanner;

public class signal1 {
	public static void main(String[] args) {
		String color;
		Scanner  sc=new Scanner(System.in);
		System.out.println("Enter the color:");
		color=sc.next();
		switch (color){
		case "red":
			System.out.println("Stop");
			break;
		case "green":
			System.out.println("Go");
			break;
		case "yellow":
			System.out.println("Ready");
			break;
		default:
		      System.out.println("No light in this color");


		}
	}

}
