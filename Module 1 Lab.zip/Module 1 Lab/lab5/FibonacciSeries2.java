package lab5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

 

public class FibonacciSeries2 {
    static Scanner scanner = new Scanner(System.in);
    static InputStreamReader obj = new InputStreamReader(System.in);
    static BufferedReader br = new BufferedReader(obj);

 

    public static void main(String[] args) throws NumberFormatException, IOException {
        while (true) {
            System.out.println("1.Fibonacci series using Non-Recursion");
            System.out.println("2.Fibonacci series using Recursion");
            System.out.println("3.exit");
            System.out.println("Enter the option");
            int option = scanner.nextInt();
            switch (option) {
            case 1:// Non Recursion
                int a = 1;
                int b = 0;
                int num, c;

 

                System.out.println("Enter N value:");
                num = scanner.nextInt();
                for (int i = 1; i <= num; i++) {
                    c = a + b;
                    System.out.println(c);
                    a = b;
                    b = c;
                }
                break;
            case 2:// Recursive Function
                class Demo {
                    int fib(int n) {
                        if (n == 1)
                            return (1);
                        else if (n == 2)
                            return (1);
                        else
                            return (fib(n - 1) + fib(n - 2));
                    }
                }
                System.out.println("enter N value");
                int n = Integer.parseInt(br.readLine());
                Demo ob = new Demo();
                System.out.println("fibonacci series is as follows");
                int res = 0;
                for (int i = 1; i <= n; i++) {
                    res = ob.fib(i);
                    System.out.println(" " + res);
                }
                System.out.println();
                System.out.println(n + "th value of the series is " + res);
                break;
            case 3:// exit
                System.exit(3);
            }

 

        }

 

    }
}
 