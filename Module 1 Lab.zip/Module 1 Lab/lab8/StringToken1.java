package lab8;

import java.util.StringTokenizer;

public class StringToken1 {
	 public static void main(String[] args) {
         
         int sum = 0;
         String a="3/1/0/7/1/9/9/9";
         StringTokenizer str=new StringTokenizer(a,"/");
          while (str.hasMoreTokens()) 
          {
              String temp = str.nextToken();
              int n = Integer.parseInt(temp);
              System.out.println(n);
              sum = sum + n;
              
          }
          System.out.println("sum="+sum);
     }

}
