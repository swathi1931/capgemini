package lab8;

import java.time.LocalDate;
import java.time.Period;

public class DateCalculation6 {
	public void dateCalculation(LocalDate ld){
	LocalDate l = LocalDate.now();
	Period p= Period.between(ld, l);
	System.out.println("Date difference :"+p.getYears()+p.getMonths()+p.getDays());}
	
	
	public static void main(String[] args) {
		LocalDate ld = LocalDate.of(2018, 04, 12);
		DateCalculation6 dc = new DateCalculation6();
		dc.dateCalculation(ld);
	}

}
