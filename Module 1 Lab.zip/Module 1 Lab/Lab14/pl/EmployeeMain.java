package com.cg.eis.pl;

import java.util.Scanner;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImp;

public class EmployeeMain {

	public static void main(String[] args) {
		
		EmployeeService abc = new EmployeeServiceImp();
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("***ENTER EMOLPYEE DETAILS***");
		
		System.out.println("Enter employee Name:");
		String employeeName = scanner.next();

		System.out.println("Enter employee ID:");
		int employeeId = scanner.nextInt();

		System.out.println("Enter employee salary:");
		int salary = scanner.nextInt();

		abc.getEmployeeDetails(employeeId, employeeName, salary);
	}

}
