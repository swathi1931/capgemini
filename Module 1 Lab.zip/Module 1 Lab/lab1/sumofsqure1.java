package lab1;

class squre {
	public int calculateDifference(int n)
	{
	int sum=0;
	int res=0,temp=0;
	for( int i=0,num;i<=n;i++){
		num=i*i;
	temp=temp+num;
	res=res*i;
	}
	res=res*res;
	sum=temp-res;
	return sum;
	}
}
public class sumofsqure1 {
public static void main(String[] args) {
	squre s=new squre();
	System.out.println(s.calculateDifference(5));
}
}
