package lab1;


import java.util.Scanner;


class DesNum{
    boolean checkNumber(int number) {
        
           boolean flag = false;
           int calc;
             
           int currentDigit = number % 10;
           calc = number/10;
            
           while(calc>0){
               if(currentDigit < calc % 10){
                  
                   flag = true;
                   break;
               }
               currentDigit = calc % 10;
               calc = calc/10;
           }
            
           if(flag){
               System.out.println(number+" Digits are not increasing number.");
           }else{
               System.out.println(number+" Digits are  increasing number.");
    }
        return flag;
}
}
public class IncreasingNumber3 {
    public static void main(String[] args) {
        DesNum obj=new DesNum();
        System.out.println("Enter a number : ");
        Scanner scanner = new Scanner(System.in);
        
           int number = scanner.nextInt();
    
    obj.checkNumber(number);
    scanner.close();
}
}
 




