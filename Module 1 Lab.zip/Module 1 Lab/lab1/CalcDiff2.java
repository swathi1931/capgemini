package lab1;

import java.util.Scanner;

public class CalcDiff2
{
     static int sum,n,i;
     public static int calculateDifference(int n)        //Calculate the difference
     {
         int a;
         int sos=(n*(n+1)*(2*n+1))/6;           //sum of squares 
         a=sos;
         
         int b=(n*(n+1))/2;                     //sum of numbers and their squares
         int c=b*b;                             //square of sum
         sum=c-a;
         return sum;
     }
public static void main(String[] args) 
{
         Scanner sc=new Scanner(System.in);
        System.out.println("Enter any number:");
        int n=sc.nextInt();
        System.out.println(CalcDiff2.calculateDifference(n));
}
}

 


//sum=(n*(n+1))/2;//sum of numbers
//sum1=sum*sum;  //square of sum(sos)
//     //sum of squares


 

