package lab10;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

 

public class CopyDataThread1 extends Thread {

 

    FileReader read;
    FileWriter write;

 

    public CopyDataThread1(FileReader read, FileWriter write) {
        this.read = read;
        this.write = write;
    }

 

    @Override
    public void run() {
        int element;
        int count = 0;
        try {
            while ((element = read.read()) != -1) {
                write.write(element);
                count++;
                if (count == 10) {
                    count = 0;
                    System.out.println("10 characters are copied");
                    sleep(10000);
                }
            }
            System.out.println("File copied successfully");
        } catch (IOException | InterruptedException ex) {
            System.out.println("Error in reading and writing file");
        } finally {
            try {
                read.close();
                write.close();
            } catch (IOException ex) {
                System.out.println("Error in reading and writing file");
            } catch (NullPointerException e) {
                System.out.println("One of the given file does not exist.");
            }

 

        }

 

    }

 

}
 