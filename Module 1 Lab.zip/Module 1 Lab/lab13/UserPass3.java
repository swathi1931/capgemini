package lab13;


interface Interface3 {
    public boolean test(String x,String y);
}
public class UserPass3 {

 

    public static void main(String[] args) {
       
        Interface3 i3 = (name,pass)->{if(name=="swathi"&&pass=="gow") return true;else return false;};
        boolean b = i3.test("swathi", "gow");
        System.out.println(b);
    }

 


}