package lab13;

@FunctionalInterface
 interface Interface2 {
    public void space(String s);
}
public class StringSpace2 {
    
        public static void main(String[] args) {
            
            Interface2 sat = (s)->{System.out.println(s.replace("", " "));};
            sat.space("Swathi");
        }

 


}

