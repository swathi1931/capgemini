package com.cap.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class Test1 {

	@Test
	public void m1() {
		System.out.println("Test case1");
	}

	@BeforeClass
	public static void m2(){
		System.out.println("Executes only one time and first");
		
	}
	@Before
	public static void m3(){
		System.out.println("Executes befour each @Test case");
		
	}
	@After
	public static void m4(){
		System.out.println("Executes after each @Test case");
		
	}
	@AfterClass
	public static void m5(){
		System.out.println("Executes only one time and last");
		
	}
	@Ignore
	public static void m6(){
		System.out.println("It will ignored by junit compiler");
		
	}
	
}
