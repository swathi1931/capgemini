package com.cap.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCase {
	Add t= new Add();
	int i = t.sum(1220,20);
	int j = 1240;

	@Test
	public void test() {
		System.out.println("sum is :"+i+" = "+j);
		assertEquals(i,j);
		
	}

}
