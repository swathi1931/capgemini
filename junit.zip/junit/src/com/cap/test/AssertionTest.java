package com.cap.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class AssertionTest {

	@Test
	public void test() {
		String obj = "junit";
		String obj1 = "junit";
		String obj2 = "test";
		String obj3 = "test";
		String obj4 = null;
		int var1 = 1;
		int var2 = 1;
		int[] arithmatic1 = {1,2,3};
		int[] arithmatic2 = {1,2,3};
		assertEquals(var1, var2);
		assertFalse(obj.equals(obj4));
		assertArrayEquals(arithmatic1, arithmatic2);
		assertNotSame(obj, obj3);
		assertNotNull(obj);
		assertNull(obj4);
		assertTrue(obj.equals(obj1));
		assertSame(obj2, obj3);
	}

}
