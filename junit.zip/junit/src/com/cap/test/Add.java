package com.cap.test;

public class Add {
	public int sum;

	int sum(int a, int b)
	{
	    return a+b;
	}

}
