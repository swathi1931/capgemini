package com.cap.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cap.bean.Account;
import com.cap.bean.Transaction;
import com.cap.exception.AccountNumberNotFoundException;
import com.cap.exception.InsuffecientAmountException;
//import com.cap.exception.InputMismatchException;

public class AccountDaoImpl implements AccountDao {
	Map<Long, Account> Account = new HashMap<Long, Account>();

	@Override
	public long WithdrawDetails(long accountno3, long WithdrawAmt) {
		// TODO Auto-generated method stub
		Account bal = Account.get(accountno3);
		if (bal == null) {
			throw new AccountNumberNotFoundException("Enter valid Account number:");
		}

		long preBal = bal.getBalance();
		long newBal = preBal - WithdrawAmt;
		bal.setBalance(newBal);

		Transaction transaction2 = new Transaction();
		transaction2.setTrancactionsId(1);
		transaction2.setFromAccount(accountno3);
		transaction2.setNewBalance(newBal);
		transaction2.setOldBalance(preBal);
		transaction2.setToAccount(accountno3);
		transaction2.setTransactionType("Withdraw");
		trans.put(transaction2, accountno3);

		return newBal;

	}

	@Override
	public com.cap.bean.Account retriveData(long accountno2) {
		// TODO Auto-generated method stub
		Account acct = Account.get(accountno2);
		if (acct == null) {
			throw new AccountNumberNotFoundException("Enter valid Account number:");
		}
		return acct;
	}

	@Override
	public void insertAccountHolder(com.cap.bean.Account account1) {
		// TODO Auto-generated method stub
		Account.put(account1.getAccountno(), account1);
	}

	@Override
	public long DepositDetails(long accountno, long DepositAmt) {
		// TODO Auto-generated method stub
		Account bal = Account.get(accountno);
		if (bal == null) {
			throw new AccountNumberNotFoundException("Enter valid Account number:");
		}

		long preBal = bal.getBalance();
		long newBal = preBal + DepositAmt;
		bal.setBalance(newBal);
		Transaction transaction2 = new Transaction();
		transaction2.setTrancactionsId(1);
		transaction2.setFromAccount(accountno);
		transaction2.setNewBalance(newBal);
		transaction2.setOldBalance(preBal);
		transaction2.setToAccount(accountno);
		transaction2.setTransactionType("Deposit");
		trans.put(transaction2, accountno);

		return newBal;

	}

	@Override
	public long FundTransfer(long accountno4, long accountno5, long fundTransfer) {
		// TODO Auto-generated method stub
		Account acc3 = Account.get(accountno4);
		if (acc3 == null) {
			throw new AccountNumberNotFoundException("Enter valid Account number:");
		}

		long preBal = acc3.getBalance();
		if (preBal < fundTransfer) {
			throw new InsuffecientAmountException("Enter valid Account number:");
		}

		long newBal = preBal - fundTransfer;
		Account acc4 = Account.get(accountno5);
		if (acc4 == null) {
			throw new AccountNumberNotFoundException("Enter valid Account number:");
		}

		long preBal1 = acc3.getBalance();
		long updBal = preBal1 + fundTransfer;
		acc3.setBalance(newBal);
		acc4.setBalance(updBal);
		Transaction transaction2 = new Transaction();
		transaction2.setTrancactionsId(1);
		// transaction2.setFromAccount(fromAccount);
		transaction2.setNewBalance(newBal);
		transaction2.setOldBalance(preBal1);
		transaction2.setToAccount(accountno5);
		transaction2.setTransactionType("FundTransfer");
		trans.put(transaction2, accountno5);

		return newBal;
	}

	Map<Transaction, Long> trans = new HashMap<Transaction, Long>();

	@Override
	public List<Transaction> printTransaction() {
		// TODO Auto-generated method stub
		System.out.println("************" + trans.size());
		List<Transaction> list = new ArrayList<Transaction>(trans.keySet());
		return list;
	}

}
