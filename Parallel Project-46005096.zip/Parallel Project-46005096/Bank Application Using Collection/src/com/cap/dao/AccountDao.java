package com.cap.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cap.bean.Account;
import com.cap.bean.Transaction;

public interface AccountDao {

	// void insertAccount(Account account1);
	long DepositDetails(long accountno, long DepositAmt);

	long WithdrawDetails(long accountno, long WithdrawAmt);

	// void createAccount(Account account1);
	Account retriveData(long accountno2);

	long FundTransfer(long accountno5, long accountno4, long fundTransfer);

	List<Transaction> printTransaction();

	Map<Transaction, Long> Account = new HashMap<Transaction, Long>();

	void insertAccountHolder(Account accountno2);

}
