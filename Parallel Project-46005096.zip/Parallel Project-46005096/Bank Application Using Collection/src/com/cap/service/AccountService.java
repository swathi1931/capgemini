package com.cap.service;

import java.util.List;

import com.cap.bean.Account;
import com.cap.bean.Transaction;

public interface AccountService {

	long DepositDetails(Long accountno1, Long depositAmt);

	long WithdrawDetails(Long accountno1, Long Withdraw);

	void insertAccountHolder(Account account1);

	Account retriveData(long accountno2);

	long FundTransfer(long accountno5, long accountno4, long FundTransfer);

	List<Transaction> printTransactions();

	boolean ValidateName(String AccountHolder);

	boolean ValidateNumber(long Mobileno);

}
