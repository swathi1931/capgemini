package com.cg.service;

import java.util.List;
import com.cg.entity.BankEntity;
import com.cg.entity.TransactionEntity;

public interface BankService {

	public List<BankEntity> createAccount(BankEntity bank);

	public BankEntity accountsDetails(Long accNo);

	public Double showBalance(Long accNo);

	public Double deposit(Long accNo, Double amt);

	public Double withdraw(Long accNo, Double amt);

	public Double fundTransfer(Long accNo1, Double amt, Long accNo2);

	public List<TransactionEntity> printTransaction(Long accNo);

}
