import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';  
import {FormsModule} from'@angular/forms';
import { AppComponent } from './app.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { PrinttransactionComponent } from './printtransaction/printtransaction.component';
import { ApproutingModule } from './approuting.module';

@NgModule({
  declarations: [
    AppComponent,
    CreateAccountComponent,
    ShowBalanceComponent,
    DepositComponent,
    WithdrawComponent,
    FundtransferComponent,
    PrinttransactionComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ApproutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
