import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { PrinttransactionComponent } from './printtransaction/printtransaction.component';
import {RouterModule,Routes} from "@angular/router"
const routes:Routes = [
  {
    path:'Create',
    component:CreateAccountComponent
    // redirectTo:'List-Student',
    // pathMatch: 'full'
  },
  {
    path:'Balance',
    component:ShowBalanceComponent
  },
  {
    path:'Deposit',
    component:DepositComponent
  },
  {
    path:'Withdraw',
    component:WithdrawComponent
  },
  {
    path:'Transfer',
    component:FundtransferComponent
  },
  {
    path:'Print',
    component:PrinttransactionComponent
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})
export class ApproutingModule { }
