package com.cap.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import com.cap.bean.Account;
import com.cap.bean.Transaction;




public class AccountDaoImpl implements AccountDao {
	private EntityManager entityManager;
	 public AccountDaoImpl() {
	        entityManager = JPAUtil.getEntityManager();
	    }
	@Override
	public Long depositDetails(long accountno, long depositAmt) {
		Account bal=entityManager.find(Account.class, accountno);
		long oldbal=bal.getBalance();
		long newbal=oldbal+depositAmt;
		bal.setBalance(newbal);
		entityManager.merge(bal);
		System.out.println(newbal);
		
		  Transaction t=new Transaction();
          t.setFromAccount(accountno);
          t.setOldBalance(oldbal);
          t.setNewBalance(newbal);
         
          entityManager.persist(t);
           return newbal;
//		 return newbal;
	}
	

	@Override
	public Long withdrawDetails(long accountno, long withdrawAmt) {
		 Account bal=entityManager.find(Account.class, accountno);
	        long oldbal=bal.getBalance();
	        long newbal=oldbal-withdrawAmt;
	        bal.setBalance(newbal);
	        entityManager.merge(bal);
	        System.out.println(newbal);
//	            return newbal;
	            
	            Transaction t=new Transaction();
	            t.setFromAccount(accountno);
	            t.setOldBalance(oldbal);
	            t.setNewBalance(newbal);
	           
	            entityManager.persist(t);
	             return newbal;
	}

	@Override
	public Long retriveData(long accountno2) {
		Account bal=entityManager.find(Account.class, accountno2);
	        return bal.getBalance();
		    }
	

	@Override
	public Long fundTransfer(long accountno5, long accountno4, long fundTransfer) {
			   Account account = entityManager.find(Account.class, accountno5);
		        long oldbalance=account.getBalance();
		        long newBalance=oldbalance-fundTransfer;
		        account.setBalance(newBalance);
		        entityManager.merge(account);
		        
		        Transaction bt=new Transaction();
		        bt.setFromAccount(accountno5);
		        bt.setOldBalance(oldbalance);
		        bt.setNewBalance(newBalance);
		        bt.setTransactionType("withdraw");
		        entityManager.persist(bt);
		        
		        Account account1 = entityManager.find(Account.class, accountno4);
		            long oldbal=account.getBalance();
		            long newBal=oldbalance+fundTransfer;
		            account1.setBalance(newBalance);
		            entityManager.merge(account);
		            
		            Transaction t=new Transaction();
		            t.setFromAccount(accountno4);
		            t.setOldBalance(oldbal);
		            t.setNewBalance(newBal);
		            t.setTransactionType("deposit");
		            entityManager.persist(t);
		           
		        return newBalance;
		    }
	

	@Override
	public  List<Transaction> printTransaction() {
		TypedQuery<Transaction> q2=entityManager.createQuery("select c from Transaction c",Transaction.class);
		 List<Transaction> l1=q2.getResultList();
		return l1;
	}

	@Override
	public Long insertAccountHolder(com.cap.bean.Account accountno2) {
		entityManager.persist(accountno2);
		return accountno2.getAccountno();
	}
	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}
      
}
	
	
	
	