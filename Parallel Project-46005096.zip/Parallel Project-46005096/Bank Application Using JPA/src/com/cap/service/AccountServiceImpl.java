package com.cap.service;



import java.util.List;

import com.cap.bean.Account;
import com.cap.bean.Transaction;
import com.cap.dao.AccountDao;
import com.cap.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	Account bean = new Account();
	AccountDao dao = new AccountDaoImpl();

	@Override
	public long depositDetails(Long accountno1, Long depositAmt) {
		dao.beginTransaction();
		long Dep = dao.depositDetails(accountno1, depositAmt);
	    dao.commitTransaction();
		return Dep;

	}

	@Override
	public long withdrawDetails(Long accountno3, Long withdraw) {
		dao.beginTransaction();
		long Wit = dao.withdrawDetails(accountno3, withdraw);
		  dao.commitTransaction();
		return Wit;
	}

	@Override
	public long retriveData(long accountno2) {
		    dao.beginTransaction();
	        long bal= dao.retriveData(accountno2);
	        dao.commitTransaction();
			return bal;
	}

	@Override
	public long fundTransfer(long accountno4, long accountno5, long fundTransfer) {
		 dao.beginTransaction();
		long fundAmt = dao.fundTransfer(accountno4, accountno5, fundTransfer);// Data Sent to dao
		 dao.commitTransaction();
		return fundAmt;// Return MainUi
	}

	@Override
	public List<Transaction> printTransactions() {
		dao.beginTransaction();
		List<Transaction> trans = dao.printTransaction();
		dao.commitTransaction();
		return trans;
	}

	@Override
	public long insertAccountHolder(Account accountno2) {
	   dao.beginTransaction();
      long acc= dao.insertAccountHolder(accountno2);
       dao.commitTransaction();
	return acc;

	}

	@Override
	public boolean validateName(String accountHolder) {
		// TODO Auto-generated method stub
		if(accountHolder.matches("[A-Z][a-zA-z]*")){
			return true;
		}else{
		return false;
	}}

	@Override
	public boolean validateNumber(long mobileNo) {
		// TODO Auto-generated method stub
		String mobNum=Long.toString(mobileNo);
        if(mobNum.matches("[6-9][0-9]{9}"))
        {
            return true;
        }
        else
        {
		return false;
	}

	}
}
