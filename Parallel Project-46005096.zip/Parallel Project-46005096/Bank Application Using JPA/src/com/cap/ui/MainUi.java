package com.cap.ui;


import java.util.List;
import java.util.Scanner;
import com.cap.bean.Account;
import com.cap.bean.Transaction;
import com.cap.exception.AccountNumberNotFoundException;
import com.cap.exception.InsuffecientAmountException;
//import com.cap.exception.InputMismatchException;
import com.cap.service.AccountService;
import com.cap.service.AccountServiceImpl;

public class MainUi {

	static AccountService service = new AccountServiceImpl();
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		while (true) {
			System.out.println("Welcome to Bank Application");
			System.out.println("1.Create Account");
			System.out.println("2.Account Details");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw ");
			System.out.println("5.Fund transfer");
			System.out.println("6.Print Transaction");
			System.out.println("7.Exit");
			int option = scanner.nextInt();
			switch (option) {
			case 1:// create Account
				String AccountHolder;
				long Mobileno = 0;
				Boolean isNum = false;
				Boolean isName = false;
				do {
					System.out.println("Enter your name:");
					AccountHolder = scanner.next();
					isName = service.validateName(AccountHolder);
					if (!isName) {
						System.out.println("Please enter first letter in Capital");
						// System.out.println("Enter your name:");
					}
				} while (!isName);
				// scanner.next();1
				

				do {
					System.out.println("Enter your mobile number: ");
					Mobileno = scanner.nextLong();
					isNum = service.validateNumber(Mobileno);
					if (!isNum) {
						System.out.println("Please Enter vaild phone number starting from 6 or 7 or 8 or 9 and having 10 digits.");
					}
				} while (!isNum);
				

				System.out.println("Enter AccountType:");
				String AccountType = scanner.next();

				System.out.println("Enter Branch");
				String branch = scanner.next();

				System.out.println("Enter Minimum Amount:");
				int Balance = scanner.nextInt();
				System.out.println("****************************");

				Account Account1 = new Account();
				Account1.setAccountHolder(AccountHolder);
				Account1.setMobileno(Mobileno);
				Account1.setAccountType(AccountType);
				Account1.setBranch(branch);
				Account1.setBalance(Balance);
				// System.out.println("****************************");

				long acc =service.insertAccountHolder(Account1);
				System.out.println("Account number:" +acc);
				System.out.println("***ACCOUNT CREATED SUCCESSFULLY***");
				System.out.println("****************************");
				break;

			case 2: // Show Balance
				try {
					System.out.println("Enter Account no:");
					long accountno2 = scanner.nextLong();
					long balance = service.retriveData(accountno2);
					System.out.println("***SHOWING BALANCE***");
					System.out.println(balance);
					System.out.println("****************************");
				} catch (AccountNumberNotFoundException e) {
					System.out.println("***CANNOT DISPLAY THE ACCOUNT***");
					System.out.println("Enter valid Account no:");
					System.out.println("****************************");
				}
				break;

			case 3: // Deposit
				try {
					System.out.println("Enter your account number:");
					Long accountno1 = scanner.nextLong();
					System.out.println("Enter the Amount to be deposited");
					Long DepositAmt = scanner.nextLong();
					long bal=service.depositDetails(accountno1, DepositAmt);
					System.out.println("Updated Balance= "+bal);
					System.out.println("***AMOUNT DEPOSITED SUCCESSFULLY***");
					System.out.println("****************************");
				} catch (AccountNumberNotFoundException e) {
					System.out.println("***CANNOT DEPOSIT***");
					System.out.println("Enter Valid Account Number:");
					System.out.println("****************************");
				}
				break;

			case 4: // Withdraw
				try {
					System.out.println("Enter your account number:");
					Long accountno3 = scanner.nextLong();
					System.out.println("Enter the Amount to be Withdrawing");
					Long WithdrawAmt = scanner.nextLong();
				    long bal=service.withdrawDetails(accountno3, WithdrawAmt);
				    System.out.println("Updated Balance= "+bal);
					System.out.println("***AMOUNT WITHDRAWN SUCCESSFULLY***");
					System.out.println("****************************");
				} catch (AccountNumberNotFoundException e) {
					System.out.println("***CANNOT WITHDRAW***");
					System.out.println("Enter Valid Account Number");
					System.out.println("****************************");

				}

				break;

			case 5: // Fund Transfer
				try {
					System.out.println("Fund Transfer");
					System.out.println("Enter the Sender Account number:");
					long acccountno7 = scanner.nextLong();
					System.out.println("Enter the Receiver Account number:");
					long acccountno8 = scanner.nextLong();
					System.out.println("Enter the account be transfer:");
					long Fundtransfer = scanner.nextLong();
					long fund=service.fundTransfer(acccountno7, acccountno8, Fundtransfer);
					System.out.println("Remaining balance of sender:" + fund);
					System.out.println("***FUND TRANSFERED SUCCESSFULLY***");
					System.out.println("****************************");
				} catch (AccountNumberNotFoundException e) {
					System.out.println("***ACCOUNT NOT FOUND***");//Account number not found Exception
					System.out.println("****************************");
					
				} catch (InsuffecientAmountException e) {
					System.out.println("***ACCOUNT NOT FOUNT***");
					System.out.println("****************************");
				}

				break;

			case 6: // Print Transaction
				System.out.println("Showing all the Transaction");
				List<Transaction> l1=service.printTransactions();
				 for(Transaction em1:l1)
		            {
		                System.out.println("Transaction ID : "+em1.getTrancactionsId());
		                System.out.println("From Account : "+em1.getFromAccount());
		                System.out.println("To Account : "+em1.getToAccount());
		                System.out.println("Old Balance : "+em1.getOldBalance());
		                System.out.println("New Balance : "+em1.getNewBalance());
		                System.out.println("***************");
		            }
//				System.out.println("****************************");
					break;
				
			case 7:// Exit
				System.out.println("***THANK YOU***");
				System.exit(0);

			}
		}

	}}


