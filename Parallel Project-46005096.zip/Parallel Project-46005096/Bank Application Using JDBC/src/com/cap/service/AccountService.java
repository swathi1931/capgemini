package com.cap.service;



import com.cap.bean.Account;


public interface AccountService {

	long depositDetails(Long accountno1, Long depositAmt);

	long withdrawDetails(Long accountno1, Long withdraw);

	long insertAccountHolder(Account account1);

	long retriveData(long accountno2);

	long fundTransfer(long accountno5, long accountno4, long fundTransfer);

	long printTransactions();

	boolean validateName(String accountHolder);

	boolean validateNumber(long mobileNo);

}
