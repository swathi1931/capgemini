package com.cap.dao;

import java.util.HashMap;
import java.util.Map;

import com.cap.bean.Account;
import com.cap.bean.Transaction;

public interface AccountDao {

	
	long depositDetails(long accountno, long depositAmt);

	long withdrawDetails(long accountno, long withdrawAmt);

	// void createAccount(Account account1);
	long retriveData(long accountno2);

	long fundTransfer(long accountno5, long accountno4, long fundTransfer);

	long printTransaction();

	Map<Transaction, Long> Account = new HashMap<Transaction, Long>();

	long insertAccountHolder(Account accountno2);

}
