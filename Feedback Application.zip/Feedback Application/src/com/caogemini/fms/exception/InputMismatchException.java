package com.caogemini.fms.exception;

@SuppressWarnings("serial")
public class InputMismatchException extends RuntimeException {
	public InputMismatchException(final String msg) {
		super(msg);

	}
}