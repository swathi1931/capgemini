package com.caogemini.fms.service;

import java.util.Map;

public interface FeedbackService {
	Map<String,Integer> addFeedbackdetails(String name,int rating,String subject);
	Map<String,Integer> getFeedbackreport();

}
