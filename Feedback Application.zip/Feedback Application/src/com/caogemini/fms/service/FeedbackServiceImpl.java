package com.caogemini.fms.service;

import java.util.Map;

import com.caogemini.fms.dao.FeedbackDAO;
import com.caogemini.fms.dao.FeedbackDAOImpl;
import com.capgemini.fms.bean.Feedback;



public class FeedbackServiceImpl implements FeedbackService {
	
	Feedback bean = new Feedback();
	FeedbackDAO dao = new FeedbackDAOImpl();

	@Override
	public Map<String, Integer> addFeedbackdetails(String name, int rating, String subject) {
		Map<String, Integer> fb = dao.addFeedbackdetails(name, rating, subject);
		return fb;
	}

	@Override
	public Map<String, Integer> getFeedbackreport() {
		
		return dao.getFeedbackreport();
	}

}
