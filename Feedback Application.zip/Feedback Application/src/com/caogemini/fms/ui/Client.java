package com.caogemini.fms.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.caogemini.fms.service.FeedbackService;
import com.caogemini.fms.service.FeedbackServiceImpl;

public class Client {
	static FeedbackService service = new FeedbackServiceImpl();
	static Scanner scanner = new Scanner (System.in);
	public static void main(String[] args) {
	

	while (true) {
		System.out.println("Welcome to Feedback Application");
		System.out.println("1.Add Feedback");
		System.out.println("2.Print Feedback Report");
		System.out.println("3.Exit");
		int option = scanner.nextInt();
		switch (option) {
		
		case 1:
			try{
			System.out.println("*************");
			System.out.println("Enter teacher name:");
			String teacherName = scanner.next();
			System.out.println("Enter subject name:");
			String topic = scanner.next();
			System.out.println("Enter rating:");
			int rating = scanner.nextInt();
			
			System.out.println(service.addFeedbackdetails(teacherName, rating, topic));
			System.out.println("***FEEDBACK ADDED***");
			}catch(InputMismatchException e){
				System.out.println(e);
				System.out.println("*************");
			}
			
			break;
		case 2:
			System.out.println("*************");
			System.out.println(service.getFeedbackreport());
			System.out.println("***FEEDBACK REPORT***");
			break;
			
		
		}
}
}}