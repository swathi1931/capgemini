package com.caogemini.fms.dao;

import java.util.Map;

public interface FeedbackDAO {
	Map<String,Integer> addFeedbackdetails(String name,int rating,String subject);
	Map<String,Integer> getFeedbackreport();

}
