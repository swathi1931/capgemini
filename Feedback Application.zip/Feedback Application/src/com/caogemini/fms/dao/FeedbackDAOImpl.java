package com.caogemini.fms.dao;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;





public class FeedbackDAOImpl implements FeedbackDAO {
	
    Map<String,Integer>MathFeedbackMap = new HashMap<String,Integer>();
    Map<String,Integer>EnglishFeedbackMap = new HashMap<> ();

	@Override
	public Map<String, Integer> addFeedbackdetails(String name, int rating, String subject) {
		
		if(subject=="maths"){
			MathFeedbackMap.put(name, rating);
		return MathFeedbackMap;
		}else if(subject == "english"){
			EnglishFeedbackMap.put(name, rating);
		return EnglishFeedbackMap;
		}else{
			throw new InputMismatchException("Enter either Maths or English");
		}
		}
		  
	

	@Override
	public Map<String, Integer> getFeedbackreport() {
		
		return null;
	}

}
