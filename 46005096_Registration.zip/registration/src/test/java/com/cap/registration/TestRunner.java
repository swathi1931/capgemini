package com.cap.registration;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		 features ="C:\\Users\\suwatm\\Desktop\\BDD Module-4\\registration\\src\\test\\resources\\register\\register.feature",
	       glue= {"com.cap.registration"},
	       //dryRun=false,
	       monochrome=true
	       //strict=true,
//	      plugin = {"pretty","html:TestOutput"}
	       )

public class TestRunner {

}
