package com.cap.dao;


import java.util.List;


import com.cap.bean.Account;
import com.cap.bean.Transaction;

public interface AccountDao {

	
	public abstract Long depositDetails(long accountno, long depositAmt);

	public abstract Long withdrawDetails(long accountno, long withdrawAmt);

	// void createAccount(Account account1);
	public abstract Long retriveData(long accountno2);

	public abstract Long fundTransfer(long accountno5, long accountno4, long fundTransfer);

	public abstract List<Transaction> printTransaction();

//	Map<Transaction, Long> Account = new HashMap<Transaction, Long>();

	public abstract Long insertAccountHolder(Account accountno2);
	
	public abstract void commitTransaction();

	public abstract void beginTransaction();

}
