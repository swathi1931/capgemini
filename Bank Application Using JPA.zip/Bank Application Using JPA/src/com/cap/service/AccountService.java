package com.cap.service;



import java.util.List;

import com.cap.bean.Account;
import com.cap.bean.Transaction;


public interface AccountService {

	long depositDetails(Long accountno1, Long depositAmt);

	long withdrawDetails(Long accountno1, Long withdraw);

	long insertAccountHolder(Account account1);

	long retriveData(long accountno2);

	long fundTransfer(long accountno5, long accountno4, long fundTransfer);

	List<Transaction> printTransactions();

	boolean validateName(String accountHolder);

	boolean validateNumber(long mobileNo);

}
