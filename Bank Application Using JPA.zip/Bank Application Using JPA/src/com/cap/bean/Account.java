package com.cap.bean;

//import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Bankdetails")
public class Account {
	@Id @GeneratedValue
//	@Column(length=20)
	private long accountNo;
//	@Column(length=20)
	private String accountHolder;
//	@Column(length=20)
	private long mobileNo;
//	@Column(length=20)
	private String accountType;
//	@Column(length=20)
	private String branch;
//	@Column(length=20)
	private long balance;
	public Account() {
		// TODO Auto-generated constructor stub
	}
	public Account(String accountHolder, long mobileNo, String accountType, String branch, long balance) {
		super();
		this.accountHolder = accountHolder;
		this.mobileNo = mobileNo;
		this.accountType = accountType;
		this.branch = branch;
		this.balance = balance;
	}
	
	

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountholder) {
		accountHolder = accountholder;
	}

	public long getMobileno() {
		return mobileNo;
	}

	public void setMobileno(long mobileno) {
		mobileNo = mobileno;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accounttype) {
		accountType = accounttype;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String Branch) {
		branch = Branch;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long Balance) {
		balance = Balance;
	}

	public long getAccountno() {
		return accountNo;
	}

	public void setAccountno(long accountno) {
		accountNo = accountno;
	}

	@Override
	public String toString() {
		return "Account [AccountHolder=" + accountHolder + ", Mobileno=" + mobileNo + ", AccountType=" + accountType
				+ ", Branch=" + branch + ", Balance=" + balance + ", Accountno=" + accountNo + "]";
	}
}
