package com.Interface;

interface Abc
{
void m1();
}
abstract class QW implements Abc
{

	void m2()
	{
		System.out.println("am  from Abstract class");
	}

}

