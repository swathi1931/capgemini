package com.DataTypes;

public class FloatEx {

	public static void main(String[] args) {
		/*
		 * float num=12.8f; float num1=12.0f; System.out.println(num+num1);
		 */
		char c = 'a';
		System.out.println((int) c);
		char b = ';';
		System.out.println((int) b);
		char z = 'A';
		System.out.println((int) z);
		char c1 = ' ';
		System.out.println((int) c1);
		System.out.println();
		

		//IDE===> INTEGRATED DEVELOPMENT ENVIRONMENT

	}

}
