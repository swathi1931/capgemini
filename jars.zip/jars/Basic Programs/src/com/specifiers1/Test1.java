package com.specifiers1;
import com.specifiers.*;
public class Test1 extends Test
{
public static void main(String[] args) 
{
	Test t=new Test();
//System.out.println(t.a);
	
}
}
