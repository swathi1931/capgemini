package com.encapsulation;

public class Bcd extends Person
{
	public static void main(String[] args)
	{
	Person a=new Person();
	
	a.setName("sandeep");
	//a.setPin();
	a.setPwd("qwe");
	
System.out.println(a.getName());
//System.out.println(a.getPin());
System.out.println(a.getPwd());

	}

}
