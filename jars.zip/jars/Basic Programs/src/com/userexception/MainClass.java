package com.userexception;

public class MainClass 
{
public static void main(String[] args)
{
	Test t=new Test();
	t.display(0);
}
}
