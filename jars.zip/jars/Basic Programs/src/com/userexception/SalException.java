package com.userexception;

public class SalException extends RuntimeException //Exception
{
		public SalException(String s) 
		{
			super(s);
		}
}
