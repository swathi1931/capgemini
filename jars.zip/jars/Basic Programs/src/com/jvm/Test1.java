package com.jvm;

public class Test1 {

	public static void main(String[] args) 
	{
	
	System.out.println(String.class.getClassLoader());
	System.out.println(Test.class.getClassLoader());
	//System.out.println(Customer.class.getClassLoader());
	}

}
