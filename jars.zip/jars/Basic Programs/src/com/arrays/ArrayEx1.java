package com.arrays;

public class ArrayEx1 
{
	public static void main(String[] args) 
	{
		//array declaration and initialization
	   int a[]=new int[10];
	   a[2]=3;
	   a[0]=12;
	   a[1]=1;
	   a[5]=10;
	   
	   System.out.println(a[1]);
	   int [] b={1,2,3};
	   
	  
		
	}
}
