package com.arrays;

import java.util.Arrays;

public class ArraysEx2
{
    public static void main(String[] args)
    {
    	int a=10;
        int ar[] = {4, 6, 1, 8, 3, 9, 7, 4, 2};
         
        // To print the elements in one line
        System.out.println(Arrays.toString(ar));
    }
}