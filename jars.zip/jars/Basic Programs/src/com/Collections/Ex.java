package com.Collections;

public class Ex {

	public static void main(String[] args)
	{	
	}

}
