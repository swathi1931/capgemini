package com.Collections;
import java.util.TreeSet;
class Hashsetdemo{
public static void main(String[] args){
//HashSet<Integer> hs = new HashSet<Integer>();
//LinkedHashSet<Integer> hs = new LinkedHashSet<Integer>();
TreeSet<String> hs=new TreeSet<String>();//treemap
hs.add("sandeep");
hs.add("suresh");
hs.add("syed");
hs.add("akash");
hs.add("rajesh");
hs.add("bolt");
hs.add("qwerty");
hs.add("syed");
System.out.println("set:" + hs);//

//[]
/*Iterator it = hs.iterator();

while(it.hasNext()){
System.out.println(it.next()+" ");
                                }*/
                     }
         }
