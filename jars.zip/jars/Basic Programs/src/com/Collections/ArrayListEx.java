package com.Collections;

import java.util.*;

public class ArrayListEx {
	public static void main(String[] args) {
		
		HashSet al = new HashSet();
		
		al.add(1);
		al.add("sandeep");
		al.add(1200.92);
		al.add(1);
		al.add("sandeep");
		
		System.out.println(al);//1,sandeep,12000.92
		
		
		
		
		
		
		
		/*Vector v = new Vector();
		System.out.println(v.capacity());//10
		v.addAll(al);
		System.out.println(v.capacity());//
		//Set he=new HashSet();
	*/
		
	}
}
