package com.Collections;

public class Comparator_Test1 
{
public static void main(String[] args) 
{
	//returns -ve =>obj1 has to come before obj2
	//returns +ve =>obj1 has to come after obj2
	//returns 0=>both objects are same 
	
	System.out.println("CL".compareTo("AM"));//+ve
	System.out.println("L".compareTo("M"));//-ve
	System.out.println("X".compareTo("X"));//0


}
}
