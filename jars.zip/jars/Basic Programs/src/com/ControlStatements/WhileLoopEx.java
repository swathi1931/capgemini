package com.ControlStatements;

public class WhileLoopEx {

	public static void main(String[] args)
	{
		int i=0;
		
		while(i<20)//while always checks for true value
		{
			System.out.println(i);
			
			i++;
		}
				
		//** while loop first check the condition then it will enters into loop

	}

}
