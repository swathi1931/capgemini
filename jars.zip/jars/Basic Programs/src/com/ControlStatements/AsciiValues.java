package com.ControlStatements;

public class AsciiValues {

	public static void main(String[] args) 
	{
	
		for(int i=0;i<=127;i++)
		{
			
			System.out.println((char)i +" "+i);
			
		}

	}

}
