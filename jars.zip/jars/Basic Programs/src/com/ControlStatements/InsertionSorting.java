package com.ControlStatements;

public class InsertionSorting {

	public static void main(String[] args) 
	{
		

	}

}
