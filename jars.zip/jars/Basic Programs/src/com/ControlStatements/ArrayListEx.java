package com.ControlStatements;

import java.util.*;
class ArrayListEx{
public static void main(String[] args)
{

LinkedHashSet set=new LinkedHashSet();

set.add("a");
set.add("a");
set.add(123);
set.add("b");
//duplicates are not allowed 
//insertion not preserved

System.out.println(set);
//if our frequent operation is retriving LinnkedList
//if our frequent operation is adding or deleting ArrayList


}
}