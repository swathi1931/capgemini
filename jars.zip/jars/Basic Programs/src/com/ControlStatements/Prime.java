package com.ControlStatements;

public class Prime 
{

	public static void main(String[] args) 
	{
		
	}

}
