package com.lamdaExpressions;

public class ConstructorReferenceEx {

}
