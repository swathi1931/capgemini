package com.lamdaExpressions;

import java.util.function.DoubleToIntFunction;

public class DoubleToIntEx {
public static void main(String[] args) {
	DoubleToIntFunction db=(i)->(int)i*2;
}
}
