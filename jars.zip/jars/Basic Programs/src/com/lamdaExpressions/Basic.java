package com.lamdaExpressions;

import java.util.Scanner;
@FunctionalInterface
interface Calci {
	public int stringLength(String name);
}
public class Basic {
	public static void main(String[] args) {
	/*	Scanner s = new Scanner(System.in);
		System.out.println("Enter first number for addition");
		String name1 = s.next();
		Calci f = name -> name.length();
		System.out.println(f.stringLength(name1));*/

	}
}