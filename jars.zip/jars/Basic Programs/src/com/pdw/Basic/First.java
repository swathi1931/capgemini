package com.pdw.Basic;


class  Second
{
public static void main(String args[])
{
System.out.println("Different class Name");
}
}