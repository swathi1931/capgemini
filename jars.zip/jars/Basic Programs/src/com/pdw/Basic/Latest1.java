package com.pdw.Basic;


public class Latest1 {

	public static void main(String[] args) 
	{
	Latest l=new Latest()
	{
		
	};
	}

}
