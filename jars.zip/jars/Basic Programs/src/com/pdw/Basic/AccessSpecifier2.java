package com.pdw.Basic;


public class AccessSpecifier2 {

	public static void main(String[] args)
	{
		AccessSpecifierEx e=new AccessSpecifierEx();
	}

}
