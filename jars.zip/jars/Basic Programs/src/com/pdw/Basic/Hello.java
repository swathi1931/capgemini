package com.pdw.Basic;
class Hello
{
static public void  main(String a[])
{
System.out.println("welcome to java ");
};
/*


*/
};
