package com.pdw.Basic;
import static java.lang.System.out;
public class StaticImportEx
{
	public static void main(String[] args) 
	{
	out.println();	
	}

}
