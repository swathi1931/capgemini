package com.pdw.Basic;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class StreamEx 
{

	public static void main(String[] args) 
	{
		List<Integer> values=Arrays.asList(1,2,3,4,5,6);
		//values.forEach(val->System.out.println(val));//1.8
	}
	
}

//switch case of c supports primitive but java switch case supports  object also.
		
		//external iterations
	
	///internal iterations
	
	
	/*	for(int i=0;i<6;i++)
	{
		System.out.println(values.get(i));
	}
   Iterator<Integer> i=values.iterator();
	while(i.hasNext())
	{
		
		System.out.println(i.next());
	}
	
	for(int val:values)
	{
		System.out.println(val);
	}*/


