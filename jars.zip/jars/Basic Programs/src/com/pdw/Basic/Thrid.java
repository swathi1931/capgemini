
package com.pdw.Basic;
class Third
{
/*public static void main(String args[])
{
System.out.println("main1");
}*/

public  void main(String a[])
{
System.out.println("main2");
}
}