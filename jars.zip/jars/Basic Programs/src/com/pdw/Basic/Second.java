package com.pdw.Basic;

 class A
{
public static void main(String args[])
{
System.out.println(" i am from class A main method");
}
}
class B
{
public static void main(String args[])
{
System.out.println(" i am from class B main method");
}
}
class C
{
public static void main(String args[])
{
System.out.println(" i am from class C main method");
}

}
class D
{
public static void main(String args[])
{
System.out.println("Multiple classes in same java file");
}
}

