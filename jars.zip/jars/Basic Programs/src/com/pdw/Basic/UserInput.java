package com.pdw.Basic;

import java.util.Scanner;

import java.lang.*;

public class UserInput {

	public static void main(String[] args) throws Exception {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first  value");
		String a=sc.next();
		System.out.println("enter second  value ");
	    int b=sc.nextInt();
	    System.out.println("name =="+a +"value"+b);
		
		//here draw back is,it will take only one char at a time 
	
		// *the return type is integer and it will take the input from the user,convert that input to char.... 
	}

}
