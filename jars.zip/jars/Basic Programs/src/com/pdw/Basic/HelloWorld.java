package com.pdw.Basic;
public class HelloWorld 
{
	/*public static final void main(String[] args) 
	{
	System.out.println("Hello World");	
	}*/

	final strictfp public static void main(String[] args) 
	{
		System.out.println("Hello World");	
		
	}
}
/*  
 
 here class is the keyword 
  final strictfp public static void main(String[] args) 
	{
	System.out.println("Hello World");	
	}
  */
