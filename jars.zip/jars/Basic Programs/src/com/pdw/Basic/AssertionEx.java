package com.pdw.Basic;

public class AssertionEx
{
	public static void main(String[] args) 
	{
		int x=10;
		;;;;;;;
		//assert simple version means one argument,agumented version means second argument.
		//assert(x>10):"x value is greater than  10"
		assert(x==10):++x;
		//assert(x<10):m1()
			;;;;;;;
		System.out.println(x);
	}
	public static int m1()
	{
		return 111;
	}
}
