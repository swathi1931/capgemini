package com.pdw.Basic;

class X //if we  are not declaring any modifier,by default it acts like default modifier.
{

}

class Y//we can't use private and protected at class level.

{

}
public class AccessSpecifierEx {

	public static void main(String[] args) {
		System.out.println("");
	}

}
/* 
  
  private-->Specific class
  
  Default -->Specific package
  
  public  -->Any class or Package
  
  Protected -->Subsiding class

if we make any variable as protected,it can access only in extended class.


  */
 