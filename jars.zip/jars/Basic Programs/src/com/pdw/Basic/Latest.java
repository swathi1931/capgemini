package com.pdw.Basic;

public interface Latest
{

	
	default void add()
	{
		
		System.out.println("interface latest");
	}
	static void mul()
	{

		System.out.println("interface latest  static");

	}
	
}
