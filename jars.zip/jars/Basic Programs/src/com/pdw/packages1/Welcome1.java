package com.pdw.packages1;

import com.pdw.packages.*;

class Welcome1 extends Welcome
{
	public void m2()
	{
		m6();
	System.out.println("HelloWorld"+a);
	}
}
class Test 
{
		public static void main(String[] args) 
	{
		Welcome w=new Welcome();
		Welcome1 w1=new Welcome1();
		
	//System.out.println(a);
	
	}

}
