package com.basc;
class X 
  {
	}
class Y
  {
	}
public class InstanceOfEx 
  {
	public static void main(String[] args)
	{
	InstanceOfEx ie=new InstanceOfEx();
	System.out.println(ie instanceof Object);
	//System.out.println(ie instanceof Y);
	
	
	//System.out.println(Class.forName(args[0]).isInstance(ie));

	}
  }
