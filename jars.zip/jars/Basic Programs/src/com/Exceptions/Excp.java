package com.Exceptions;

class Excp {
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "i have many gf";
	}
	public static void main(String args[]) {
		Excp e=new Excp();
		System.out.println(e.toString());
		System.out.println(e);
	}
}
