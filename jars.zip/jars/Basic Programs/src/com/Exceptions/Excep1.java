package com.Exceptions;

class Excep1
{
	 public static void main(String[] args)throws Exception
 {

   int arr[]={1,2,3,4};
   arr[2]=10/2;//ArrayIndexOutOfBoundsException
   int a=10;
   int b=2;
   int c=a/b;
   String s=null;
  s.length();
 System.out.println("remaining lines");
 
}}