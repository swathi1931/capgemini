package com.Exceptions;

public class ToStringTest 
{
	@Override
		public String toString() {
			// TODO Auto-generated method stub
			return "dont sleep";
		}
public static void main(String[] args) {
	ToStringTest t=new ToStringTest();
	System.out.println(t.toString());//toString
}
}
