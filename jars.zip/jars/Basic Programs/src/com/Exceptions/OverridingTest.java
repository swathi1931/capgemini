package com.Exceptions;
class A1
{
	

	}
public class OverridingTest extends A1
{

}
