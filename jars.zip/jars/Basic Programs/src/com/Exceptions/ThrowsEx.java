package com.Exceptions;

public class ThrowsEx {
	public static void main(String[] args) throws Exception {
		
			int a = 10;
			int b = 0;
			int c;
			c = a / b;
		System.out.println("100 lines of code");
	}

}
