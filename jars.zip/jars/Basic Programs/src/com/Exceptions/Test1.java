package com.Exceptions;

import java.util.Scanner;

public class Test1 
{
	public static void main(String[] args) 
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your first number :");
		int a=sc.nextInt();
		System.out.println("Enter your second number :");
		int b=sc.nextInt();
		
		System.out.println("Addition of your two numbers is:"+(a+b));
		
	}
}
