package com.secondpack;

import com.firstpackage.A;

public class B  {
public static void main(String[] args) {
	A  a=new A();
	a.m1();
}
}
