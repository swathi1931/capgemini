package com.collection.concurrentCollectionEx;

import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapWith8Ex 
{
public static void main(String[] args) {
	ConcurrentHashMap<Integer, String> chm=new ConcurrentHashMap<Integer,String>();
	chm.put(1,"raghava");
	chm.put(2,"maruthi");
	chm.put(3,"viswa");
	chm.put(4,"santhosh");
	}
}
