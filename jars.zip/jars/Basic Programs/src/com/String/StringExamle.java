package com.String;

public class StringExamle 
{
	public static void main(String[] args) 
	{
		
	String s="welcome";
	String s1="WELCOME";
	String s2=new String("welcome");
	String s3=new String("welcome");
	}
}
