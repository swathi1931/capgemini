package com.String;
public class StringEx2 
{
public static void main(String[] args) 
{
String s =new String("abc");	
String s1=new String("abc");
String s2="abc";
String s3="abc";
s1=s1.intern();
//s=s+s1;
System.out.println(s==s2);
System.out.println(s2==s3);
System.out.println(s1==s2);
}
}
