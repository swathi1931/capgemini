package com.String;
public class StringEx1 
{
	public static void main(String[] args) 
	{
		String s=new String("wel");
		 String s1=new String("wel1");
		//  s=s1;
		String s3= s.concat(s1);
		System.out.println(s);
		 System.out.println(s3);
		/* StringBuffer sb=new StringBuffer();
		 sb.append("wel");
		 sb.append("wel1");
		 System.out.println(sb);*/
		/*String s=new String("pranay");
		String s1=new String("pranay1");
		System.out.println(s);
		String s2=s+s1;
		System.out.println(s2);
		String s3=s.concat(s2);*/
	/*	System.out.println(s3);*/
	}
}
