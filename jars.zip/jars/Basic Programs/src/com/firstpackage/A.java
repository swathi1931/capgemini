package com.firstpackage;

public class A {

	public void m1()
	{
		System.out.println("A class m1 method");
	}
}
 class X{
public static void main(String[] args) {
	A a=new A();
	a.m1();
}
	
}
