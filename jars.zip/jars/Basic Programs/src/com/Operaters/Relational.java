package com.Operaters;

public class Relational {

	public static void main(String[] args)

	{
		int a = 121;
		int b = 123;
		 if(a==b)
		 {
			 System.out.println("Relational Operater:weather two operands are equal or not");
			
			 if(a>b)
		    	 System.out.println("the value of a is greater than b");
		     
			 if(a<b)
		    	 System.out.println("the value of a is less than b");
		     
		 }
	     if(a!=b)
			System.out.println("two values are not equal");	     
	     
	     
	     
	}
	/*
	
	 ==   it is used to compare two operands it will give true if the values are same other wise  false.
	 !=if the values are not equal it will give true.
	 <
	 >
	 <=
	 >= 
	 
	 
	 
*/
}
