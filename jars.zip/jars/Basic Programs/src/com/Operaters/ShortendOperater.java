package com.Operaters;

public class ShortendOperater 
{

	public static void main(String[] args)
	{
		int i =10;
		i+=2;
		System.out.println(i);
       i-=2;
       System.out.println(i);
       i*=2;
       System.out.println(i);
	}

}
