package com.Operaters;
public class ArithmeticEx1 {
	 public static void main(String[] args) {
	  //Variables Definition and Initialization
	  int number1 = 12, number2 = 4;

	  //Addition Operation
	  int sum = number1 + number2;
	  System.out.println("Sum is: " + sum);

	  //Subtraction Operation
	  int dif = number1 - number2;
	  System.out.println("Difference is : " + dif);

	  //Multiplication Operation
	  int mul = number1 * number2;
	  System.out.println("Multiplied value is : " + mul);

	  //Division Operation
	  int div = number1 / number2;
	  System.out.println("Quotient is : " + div);

	  //Modulus Operation
	  int rem = number1 % number2;
	  System.out.println("Remainder is : " + rem);

	 }
	}