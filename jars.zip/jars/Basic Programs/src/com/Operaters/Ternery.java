package com.Operaters;

public class Ternery 
{

	public static void main(String[] args) 
	{
	//	int a;
		int i = 0;
	
		
		int a = (i == 1) ? 10:5;
		
		//if i==0 is valid it will give next value like 10 if not it will give 5
		
		//epr1 ? expr2 : expr3
		//If epr1Condition is true? Then value expr2 : Otherwise value expr3

		
		System.out.println(a);
		
		/*if (i == 0)
		{
		    a = 10;
		}
		else
		{
		    a = 5;
		*/

		
		
	}
}

/*//Java program to illustrate 
//max of three numbers using 
//ternary operator. 
public class operators 
{ 
	public static void main(String[] args) 
	{ 
		int a = 20, b = 10, c = 30, result; 

		//result holds max of three 
		//numbers 
		result = ((a > b) ? (a > c) ? a : 
				c : (b > c) ? b : c); 
		System.out.println("Max of three numbers = "+result); 
	} 
} */

