package com.Operaters;
class B{}
class A{}  
class newoperater extends A
{
  
 public static void main(String args[]){  
 newoperater d=new newoperater();  
 System.out.println(d instanceof newoperater);//true  
 }  
} 
