package com.Operaters;

public class Logical {

	public static void main(String[] args)
	{
	
	/*     
    &&     Logical AND 
	
	||     Logical OR
	
	!      Logical NOT	
	*/	
		int a=20;
		int b=20;
		
		if(a==b && a<=b )
		{
			
			System.out.println("logical AND");
		}
		else if(a==b || a<b )
		{
			
			System.out.println("logical OR");
		}

	}
}
