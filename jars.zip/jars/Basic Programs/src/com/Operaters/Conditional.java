package com.Operaters;

public class Conditional 
{
	public static void main(String[] args) 
	{
		
	}
}
