
public class TestEmp {
public static void main(String[] args) {
	Emp e=new Emp();
	e.setEid(123);
	e.setName("sandeep");
	e.setAtmpin(1234);
	System.out.println(e.getEid());
	//System.out.println(e.getAtmpin());
}
}
