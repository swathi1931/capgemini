package polymorphism;
public class OperaterOverloadingEx 
{
	public static void main(String[] args) 
	{
		System.out.println(10+20);//30
		System.out.println("sandeep"+"pdw");//sandeeppdw
		System.out.println("sandeep"+10);//sandeep10
		System.out.println(10+10+"wel"+"come"+30);//20welcome30
		System.out.println(10+"wel"+"come"+30+10);//10welcome30+10
		System.out.println(10+"wel"+"come"+30+10+11);//10welcome30+10+11
	}
}
