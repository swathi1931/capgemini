interface A1
{
	int a=20;//static final int a=10
	void m4();//public abstract void m4();
	}

/*final
 * 
 * 	@variable
 * 	@method
 *  @class
 * 
*/
abstract class Welcome2
{
	void m1()
	{
		System.out.println("m1 method");
	}
	abstract void m2();
	}
public class Welcome1 
{
public static void main(String[] args) {
	System.out.println("welcome");
}
}
