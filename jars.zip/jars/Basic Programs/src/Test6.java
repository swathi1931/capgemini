
public class Test6 {
	public static void main(String[] args) {
	
		Address a=new Address(123,"medak","ts","india");
		Emp1 e=new Emp1(1,"suresh",1234, 26,a);
		System.out.println(e.toString());

	}

}
