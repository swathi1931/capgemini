package Final;

public class BeanClass1 {

	public static void main(String[] args) 
	{
		BeanClass b=new BeanClass();
		b.setId(1);
		b.setName("qwerty");
		b.setAddress("HYD");
		System.out.println(b.getId()+"  "+b.getName()+" "+b.getAddress());
		
	}

}
