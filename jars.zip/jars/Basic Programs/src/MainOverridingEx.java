
class p
{
public static void main(String [] args)
{
System.out.println("parent main");
}
}
public class MainOverridingEx extends p
{
public static void main(String [] args)
{
System.out.println("child main");
}
}
